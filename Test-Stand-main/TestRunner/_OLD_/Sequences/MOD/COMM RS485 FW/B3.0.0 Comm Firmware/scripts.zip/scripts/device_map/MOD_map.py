trip_state = 0x8001

sid_number = 0x5
production_lock_register = 0x11

enable_switching_via_input = 0x8002
enable_switching_via_communication = 0x8003

update_initialize = 0x100
update_run = 0x101
update_block_data_upload = 0x102
